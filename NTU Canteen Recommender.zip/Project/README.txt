Below are the parts of our program and the distribution of who did what:
Functions in our program:
search_canteen()                                         ##Implemented by Ritik B.
search_rank()                                            ##Implemented by Ritik B.
search_food()                                            ##Implemented by Ritik B.
search_stall()                                           ##Implemented by Ritik B.
sort_rating()                                            ##Implemented by Manav Arora
sort_price()                                             ##Implemented by Manav Arora
sort_distance()                                          ##Implemented by Manav Arora
transit()                                                ##Implemented by Manav Arora
cal_dist()                                               ##Implemented by Manav Arora
update()(including update location)                      ##Implemented by Ritik B.
crowd()                                                  ##Implemented by Ritik B.
favourites()(includes add/delete and print favourites)   ##Implemented by Ritik B.

database                                                 ##Implemented by Manav Arora
User Interface(display_map() and display_map_ref())      ##Implemented by Ritik B.


Following pacakages need to be downloaded to use the program:
pygame
math
operator
time
datetime
sys
matplotlib.pyplot
matplotlib.image
database(in the zip file)

All the images used in the program are provided in the zip file.
